#pragma once
#include "valve_sdk/csgostructs.hpp"
#include "options.hpp"
namespace Skins {
	void OnFrameStageNotify(ClientFrameStage_t stage);
};
